#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/adc.h"
#include "hardware/pwm.h"
#include "hardware/gpio.h"
#include "hardware/uart.h"

// ==========================================
// CONFIGURAÇÃO DE PINOS
// ==========================================
#define UART_ID uart0
#define BAUD_RATE 9600
#define UART_TX_PIN 0
#define UART_RX_PIN 1

// Sensores
#define PIN_FLOW    13
#define PIN_DS18B20 14  
#define PIN_DHT     15  // <--- NOVO SENSOR (AR)
#define PIN_SERVO   16
#define PIN_LDR     26
#define PIN_TDS     27
#define PIN_LED_INTERNO 25

// ==========================================
// PARÂMETROS
// ==========================================
#define INTERVALO_VERIFICACAO_MS 900000 
#define EC_ALVO_US 1600                 

// Servo
#define PWM_DIVISER 64.0f
#define PWM_WRAP 39062
#define SERVO_MIN 1300
#define SERVO_MAX 4800

// ==========================================
// DRIVER DHT11 (Manual - Bit Banging)
// ==========================================
typedef struct {
    float humidity;
    float temp_celsius;
    bool error;
} dht_reading_t;

void wait_micros(uint32_t us) {
    sleep_us(us);
}

dht_reading_t ler_dht11(uint pin) {
    dht_reading_t result = {0.0, 0.0, true};
    uint8_t data[5] = {0, 0, 0, 0, 0};
    uint last = 1;

    // 1. Sinal de Start
    gpio_set_dir(pin, GPIO_OUT);
    gpio_put(pin, 0);
    sleep_ms(18); // Low por 18ms
    gpio_put(pin, 1);
    sleep_us(40);
    gpio_set_dir(pin, GPIO_IN);

    // 2. Espera resposta do sensor (Loop com timeout para não travar)
    // O sensor manda Low 80us depois High 80us. Ignoramos checagem rigorosa para simplificar.
    
    // 3. Leitura dos 40 bits
    for (uint i = 0; i < 40; i++) {
        uint timeout = 0;
        while (!gpio_get(pin)) { // Espera ficar HIGH
            if (++timeout > 1000) return result; // Timeout
            sleep_us(1);
        }
        
        uint32_t t = 0;
        while (gpio_get(pin)) { // Mede quanto tempo fica HIGH
            if (++t > 1000) break; 
            sleep_us(1);
        }

        // Se ficou HIGH por muito tempo (> ~30-40us), é bit 1. Se pouco, é bit 0.
        // O limiar seguro é ~28us, mas vamos usar shift direto.
        // Nota: sleep_us(1) não é super preciso, mas funciona para DHT11.
        if (t > 28) {
            data[i / 8] |= (1 << (7 - (i % 8)));
        }
    }

    // 4. Verificação (Checksum)
    if (data[4] == ((data[0] + data[1] + data[2] + data[3]) & 0xFF)) {
        result.humidity = (float)data[0] + (float)data[1] / 10.0f;
        result.temp_celsius = (float)data[2] + (float)data[3] / 10.0f;
        result.error = false;
    }
    return result;
}

// ==========================================
// DRIVER DS18B20 (Manual)
// ==========================================
// (Copiado da versão anterior - omitindo detalhes para economizar espaço visual, mas inclua no seu!)
void one_wire_reset(uint pin) {
    gpio_set_dir(pin, GPIO_OUT); gpio_put(pin, 0); sleep_us(480);
    gpio_set_dir(pin, GPIO_IN); sleep_us(70); sleep_us(410);
}
void one_wire_write_byte(uint pin, uint8_t data) {
    for (int i=0; i<8; i++) {
        gpio_set_dir(pin, GPIO_OUT); gpio_put(pin, 0);
        if (data & 1) { sleep_us(10); gpio_set_dir(pin, GPIO_IN); sleep_us(55); }
        else { sleep_us(65); gpio_set_dir(pin, GPIO_IN); sleep_us(5); }
        data >>= 1;
    }
}
uint8_t one_wire_read_byte(uint pin) {
    uint8_t data=0;
    for (int i=0; i<8; i++) {
        gpio_set_dir(pin, GPIO_OUT); gpio_put(pin, 0); sleep_us(3);
        gpio_set_dir(pin, GPIO_IN); sleep_us(10);
        if (gpio_get(pin)) data |= (1<<i);
        sleep_us(53);
    }
    return data;
}
float ler_ds18b20(uint pin) {
    one_wire_reset(pin); one_wire_write_byte(pin, 0xCC); one_wire_write_byte(pin, 0x44);
    // Não esperamos 750ms aqui para não travar o DHT. Esperamos no loop.
    return 0.0; // Dummy return, leitura real feita em duas etapas no loop
}
float ler_ds18b20_resultado(uint pin) {
    one_wire_reset(pin); one_wire_write_byte(pin, 0xCC); one_wire_write_byte(pin, 0xBE);
    uint8_t l = one_wire_read_byte(pin); uint8_t h = one_wire_read_byte(pin);
    return ((h<<8)|l)/16.0f;
}

// ==========================================
// MAIN
// ==========================================
volatile uint32_t pulse_count = 0;
void gpio_callback(uint gpio, uint32_t events) { if(gpio==PIN_FLOW) pulse_count++; }
float calcular_fluxo(uint32_t p, uint32_t t) { return (t==0)?0:((float)p/(t/1000.0f))/7.5f; }
void mover_servo(uint s, uint c, uint16_t l) { pwm_set_chan_level(s, c, l); }

int main() {
    stdio_init_all(); 
    uart_init(UART_ID, BAUD_RATE);
    gpio_set_function(UART_TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(UART_RX_PIN, GPIO_FUNC_UART);
    uart_set_format(UART_ID, 8, 1, UART_PARITY_NONE);
    uart_set_hw_flow(UART_ID, false, false);

    adc_init(); adc_gpio_init(PIN_LDR); adc_gpio_init(PIN_TDS);
    gpio_init(PIN_LED_INTERNO); gpio_set_dir(PIN_LED_INTERNO, GPIO_OUT);

    gpio_init(PIN_DHT); gpio_set_dir(PIN_DHT, GPIO_IN); gpio_pull_up(PIN_DHT);
    gpio_init(PIN_DS18B20); gpio_set_dir(PIN_DS18B20, GPIO_IN); gpio_pull_up(PIN_DS18B20);
    
    gpio_init(PIN_FLOW); gpio_set_dir(PIN_FLOW, GPIO_IN); gpio_pull_up(PIN_FLOW);
    gpio_set_irq_enabled_with_callback(PIN_FLOW, GPIO_IRQ_EDGE_RISE, true, &gpio_callback);

    gpio_set_function(PIN_SERVO, GPIO_FUNC_PWM);
    uint slice = pwm_gpio_to_slice_num(PIN_SERVO);
    uint channel = pwm_gpio_to_channel(PIN_SERVO);
    pwm_set_clkdiv(slice, PWM_DIVISER); pwm_set_wrap(slice, PWM_WRAP); pwm_set_enabled(slice, true);
    mover_servo(slice, channel, SERVO_MIN);

    printf("\r\n=== MONITOR HIDROPONICO COMPLETO ===\r\n");

    uint32_t last_time_flow = to_ms_since_boot(get_absolute_time());
    uint32_t last_time_dose = to_ms_since_boot(get_absolute_time());
    uint32_t last_temp_req = 0;

    // Inicia primeira conversão de temperatura da água
    one_wire_reset(PIN_DS18B20); one_wire_write_byte(PIN_DS18B20, 0xCC); one_wire_write_byte(PIN_DS18B20, 0x44);
    last_temp_req = to_ms_since_boot(get_absolute_time());

    while (true) {
        // --- Leituras Analógicas ---
        adc_select_input(0); uint16_t ldr = adc_read();
        adc_select_input(1); float ec = (((adc_read()*3.3f)/4095.0f)*500.0f)*2.0f;

        // --- Fluxo ---
        uint32_t now = to_ms_since_boot(get_absolute_time());
        uint32_t diff = now - last_time_flow;
        uint32_t p = pulse_count; pulse_count=0; last_time_flow=now;
        float fluxo = calcular_fluxo(p, diff);

        // --- Temperatura Água (DS18B20) ---
        // Lógica não-bloqueante: Se passou 1s desde o pedido, lê o dado e pede outro
        float temp_agua = 0.0;
        if (now - last_temp_req > 1000) {
            temp_agua = ler_ds18b20_resultado(PIN_DS18B20);
            // Pede nova conversão para o próximo loop
            one_wire_reset(PIN_DS18B20); one_wire_write_byte(PIN_DS18B20, 0xCC); one_wire_write_byte(PIN_DS18B20, 0x44);
            last_temp_req = now;
        }

        // --- Temperatura Ar (DHT11) ---
        // ATENÇÃO: Essa leitura trava o código por ~20ms. Aceitável.
        dht_reading_t dht = ler_dht11(PIN_DHT);
        
        // --- Output ---
        uint32_t t_rest = (INTERVALO_VERIFICACAO_MS>(now-last_time_dose))?(INTERVALO_VERIFICACAO_MS-(now-last_time_dose))/1000:0;
        
        // Print Formatado para Celular (Bluetooth)
        printf("\f"); // Limpa tela em alguns terminais
        printf("--- HIDROPONIA ---\r\n");
        printf("Ar: %.1fC / %.0f%%\r\n", dht.temp_celsius, dht.humidity);
        printf("Agua: %.1f C\r\n", temp_agua);
        printf("EC: %.0f uS\r\n", ec);
        printf("Luz: %u\r\n", ldr);
        printf("Fluxo: %.1f L/m\r\n", fluxo);
        printf("Timer: %us\r\n", t_rest);
        
        // LED Heartbeat
        gpio_put(PIN_LED_INTERNO, 1); sleep_ms(50); gpio_put(PIN_LED_INTERNO, 0);

        // --- Automação ---
        if ((now - last_time_dose) >= INTERVALO_VERIFICACAO_MS) {
            printf("\r\n>> VERIFICANDO...\r\n");
            // Segurança: Só dosa se Temp Agua > 10 e DHT não deu erro
            if (ec < EC_ALVO_US && temp_agua > 10.0 && !dht.error) {
                printf(">> DOSANDO!\r\n");
                mover_servo(slice, channel, SERVO_MAX);
                sleep_ms(2000);
                mover_servo(slice, channel, SERVO_MIN);
            } else {
                printf(">> PARAMETROS OK.\r\n");
            }
            last_time_dose = now;
        }

        sleep_ms(2000); // Loop a cada 2 segundos para dar folga ao DHT11
    }
    return 0;
}